chrome.webNavigation.onCompleted.addListener(function(details) {
	if (details.url.startsWith('https://www.g2a.com/')) {
		chrome.tabs.executeScript(details.tabId, {
			file: 'inject.js'
		});
	}
}, {url: [{urlMatches : 'https://www.g2a.com/*'}]});